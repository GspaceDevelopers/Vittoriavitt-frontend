import React, { useContext, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { toast } from "react-toastify";
import { AuthContext } from "../../Contexts/auth";
import Star from "../../Assets/star/star.png";
import Starvazia from "../../Assets/star/estrela vazia.png";
import "./Styles.css";
import { array } from "i/lib/util";

const Comentario = (props) => {
  const { usercliente } = useContext(AuthContext);
  const { _id } = useParams();
  const [comentario, setComentario] = useState();
  const [comentarioget, setComentarioget] = useState([]);
  const [avaliacaostar, setAvaliacaostar] = useState("");
  const [avaliacao, setAvaliacao] = useState();
  const [avaliacaoarray, setAvaliacaoarray] = useState([]);
  const [statenumerofinal, setStatenumerofinal] = useState();
  const [soma, setSoma] = useState();
  let array = [];
  useEffect(() => {
    axios
      .get(`http://localhost:3333/comentarios/idproduto?idproduto=${_id}`)
      .then((data) => {
        setComentarioget(data.data);
        comentarioget.map((item) => {
          array.push(Number(item.star));
          return console.log(array);
        });
        console.log(array.length);
        setAvaliacaoarray(data.data.star);
        console.log(array);
        var somafinal = 0;
        for (var soma = 0; soma < array.length; soma += 1) {
          somafinal += array[soma];
          if (array.length == 1) {
            return setStatenumerofinal(somafinal);
          } else {
            console.log(` esse numero${somafinal}`);
            console.log(somafinal / array.length);
            setStatenumerofinal(Math.round(somafinal / array.length));
          }
        }
      });
  }, [comentarioget]);

  async function enviarComentarios() {
    let config = {
      headers: "Access-Control-Allow-Origin",
    };

    let data = {
      user: usercliente.nome,
      idproduto: _id,
      star: avaliacaostar,
      comentario: comentario,
      printcomentario: true,
    };

    let url = "http://localhost:3333/comentarios";
    if (comentario == "") {
      return toast.error("Escreva algum comentario sobre o produto");
    } else {
      await axios
        .post(url, data, config)
        .then((result) => {
          console.log(_id);

          console.log(result);
          toast.success("Comentario enviado");
          setComentario("");
          window.location.reload();
        })
        .catch((error) => {
          toast.error("Faça o login para comentar");
          alert(error);
          setComentario("");
        });
    }
  }
  return (
    <>
      <div id="div-comentario-main">
        <div className="comentarios-second">
          <div id="avaliacao-media-valor">
            {" "}
            <div className="state-id-number-media">
              <h1 id="comentarios-titulo-avaliacoes">Avaliações:</h1>
              <h2>{statenumerofinal}</h2>
              {statenumerofinal == 5 ? (
                <>
                  {" "}
                  <div id="star">
                    {" "}
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />{" "}
                  </div>
                </>
              ) : (
                ""
              )}
              {statenumerofinal == "" ? (
                <>
                  {" "}
                  <div id="star">
                    {" "}
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />{" "}
                  </div>
                </>
              ) : (
                ""
              )}
              {statenumerofinal == 1 ? (
                <>
                  {" "}
                  <div id="star">
                    {" "}
                    <img src={Star} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />{" "}
                  </div>
                </>
              ) : (
                ""
              )}
              {statenumerofinal == 2 ? (
                <>
                  {" "}
                  <div id="star">
                    {" "}
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />{" "}
                  </div>
                </>
              ) : (
                ""
              )}{" "}
              {statenumerofinal == 3 ? (
                <>
                  {" "}
                  <div id="star">
                    {" "}
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />{" "}
                  </div>
                </>
              ) : (
                ""
              )}
              {statenumerofinal == 4 ? (
                <>
                  {" "}
                  <div id="star">
                    {" "}
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Star} alt="" srcset="" />
                    <img src={Starvazia} alt="" srcset="" />{" "}
                  </div>
                </>
              ) : (
                ""
              )}
            </div>
            <div className="second-media-div">
              <a href="#anc-id-teste-avaliar-produt-anc">Avaliar Produto</a>
            </div>
          </div>
          {comentarioget.length == 0 ? (
            <div>
              {" "}
              <p>Não há comentarios</p>{" "}
            </div>
          ) : (
            ""
          )}

          {comentarioget.map((item) => {
            return (
              <div className="style-comentario-user">
                {" "}
                <p id="usernamecommet">{item.user}</p>
                {item.star == "5" ? (
                  <>
                    {" "}
                    <div id="star">
                      {" "}
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />{" "}
                    </div>
                  </>
                ) : (
                  ""
                )}
                {item.star == "" ? (
                  <>
                    {" "}
                    <div id="star">
                      {" "}
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />{" "}
                    </div>
                  </>
                ) : (
                  ""
                )}
                {item.star == "1" ? (
                  <>
                    {" "}
                    <div id="star">
                      {" "}
                      <img src={Star} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />{" "}
                    </div>
                  </>
                ) : (
                  ""
                )}
                {item.star == "2" ? (
                  <>
                    {" "}
                    <div id="star">
                      {" "}
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />{" "}
                    </div>
                  </>
                ) : (
                  ""
                )}{" "}
                {item.star == "3" ? (
                  <>
                    {" "}
                    <div id="star">
                      {" "}
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />{" "}
                    </div>
                  </>
                ) : (
                  ""
                )}
                {item.star == "4" ? (
                  <>
                    {" "}
                    <div id="star">
                      {" "}
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Star} alt="" srcset="" />
                      <img src={Starvazia} alt="" srcset="" />{" "}
                    </div>
                  </>
                ) : (
                  ""
                )}
                <p>{item.comentario}</p>{" "}
              </div>
            );
          })}
          <div id="anc-id-teste-avaliar-produt-anc"></div>
          <div className="comment-primary-input-comentar">
            <ul class="avaliacao">
              <li
                class="star-icon ativo"
                data-avaliacao="1"
                onClick={() => {
                  setAvaliacaostar("1");
                  var stars = document.querySelectorAll(".star-icon");

                  document.addEventListener("click", function (e) {
                    var classStar = e.target.classList;
                    if (!classStar.contains("ativo")) {
                      stars.forEach(function (star) {
                        star.classList.remove("ativo");
                      });
                      classStar.add("ativo");
                      console.log(e.target.getAttribute("data-avaliacao"));
                    }
                  });
                }}
              ></li>
              <li
                class="star-icon"
                data-avaliacao="2"
                onClick={() => {
                  setAvaliacaostar("2");
                  var stars = document.querySelectorAll(".star-icon");

                  document.addEventListener("click", function (e) {
                    var classStar = e.target.classList;
                    if (!classStar.contains("ativo")) {
                      stars.forEach(function (star) {
                        star.classList.remove("ativo");
                      });
                      classStar.add("ativo");
                      console.log(e.target.getAttribute("data-avaliacao"));
                    }
                  });
                }}
              ></li>
              <li
                class="star-icon"
                data-avaliacao="3"
                onClick={() => {
                  setAvaliacaostar("3");
                  var stars = document.querySelectorAll(".star-icon");

                  document.addEventListener("click", function (e) {
                    var classStar = e.target.classList;
                    if (!classStar.contains("ativo")) {
                      stars.forEach(function (star) {
                        star.classList.remove("ativo");
                      });
                      classStar.add("ativo");
                      console.log(e.target.getAttribute("data-avaliacao"));
                    }
                  });
                }}
              ></li>
              <li
                class="star-icon"
                data-avaliacao="4"
                onClick={() => {
                  setAvaliacaostar("4");
                  var stars = document.querySelectorAll(".star-icon");

                  document.addEventListener("click", function (e) {
                    var classStar = e.target.classList;
                    if (!classStar.contains("ativo")) {
                      stars.forEach(function (star) {
                        star.classList.remove("ativo");
                      });
                      classStar.add("ativo");
                      console.log(e.target.getAttribute("data-avaliacao"));
                    }
                  });
                }}
              ></li>
              <li
                class="star-icon"
                data-avaliacao="5"
                onClick={() => {
                  setAvaliacaostar("5");
                }}
              ></li>
            </ul>

            <div className="black-shadow">
              <div className="input-avaliação-teste">
                <input
                  type="text"
                  placeholder="Deixe seu comentário sobre o produto..."
                  value={comentario}
                  onChange={(e) => {
                    setComentario(e.target.value);
                    var stars = document.querySelectorAll(".star-icon");

                    document.addEventListener("click", function (e) {
                      var classStar = e.target.classList;
                      if (!classStar.contains("ativo")) {
                        stars.forEach(function (star) {
                          star.classList.remove("ativo");
                        });
                        classStar.add("ativo");
                        console.log(e.target.getAttribute("data-avaliacao"));
                      }
                    });
                  }}
                />{" "}
                <button onClick={enviarComentarios}>Enviar</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Comentario;
